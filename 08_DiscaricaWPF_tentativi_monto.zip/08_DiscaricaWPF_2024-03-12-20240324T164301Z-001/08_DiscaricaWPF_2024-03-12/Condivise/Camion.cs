﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Impianto
{
    class Camion
    {
        int capienza = 0; // massimo 100
        int volume = 0;
        int Contenuto; 
        bool vita = true;
        
        public int Capienza { get; private set; }
        public int GetContenuto { get { return Contenuto; } }
        public int SetContenuto { set { Contenuto = value; } }
        public int GetVolume { get { return volume; } }
        public int SetVolume { set { volume = value; } }

        public bool SetVita { set { vita = value; } }

        public void RiempiCamion()
        {
            Random r = new Random();
            Contenuto = r.Next(0,5);
            
            Capienza = r.Next(50,101);
            volume = Contenuto * Capienza;

            Azione();
        }
        public void SvuotaCamion()
        {
            vita=false; //se è vuoto il camion muore
        }

        public void Azione()
        {
            while (vita)
            {

            }
        }
    }
}
