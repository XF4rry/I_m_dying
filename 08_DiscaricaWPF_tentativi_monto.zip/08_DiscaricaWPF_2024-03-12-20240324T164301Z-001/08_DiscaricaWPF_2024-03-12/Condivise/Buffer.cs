﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Impianto
{
    public class Buffer<T>
    {
        private T[] buffer;
        private int capienza;
        private int scrivi;
        private int leggi;
        private int count;
        private double[] pointX;
        private double[] pointY;
        public double X
        {
            get
            {
                return pointX[scrivi - 1];
            }
        }
        public double Y
        {
            get
            {
                return pointY[scrivi - 1];
            }
        }

        public Buffer(int capacity, double[] pointX, double[] pointY)
        {
            this.capienza = capacity;
            buffer = new T[capacity];
            scrivi = 0;
            leggi = 0;
            count = 0;
            this.pointX = pointX;
            this.pointY = pointY;
        }

        public void Aggiungi(T item)
        {
            if (count == capienza)
            {
                throw new InvalidOperationException("Il buffer è pieno");
            }

            buffer[scrivi] = item;
            scrivi = (scrivi + 1) % capienza;
            count++;
        }

        public T Togli()
        {
            if (count == 0)
            {
                throw new InvalidOperationException("Il buffer è vuoto");
            }

            T item = buffer[leggi];
            leggi = (leggi + 1) % capienza;
            count--;

            return item;
        }

        public T Leggi()
        {
            if (count == 0)
            {
                throw new InvalidOperationException("Il buffer è vuoto");
            }

            return buffer[leggi];
        }

        public int Count
        {
            get { return count; }
        }

        public bool IsEmpty
        {
            get { return count == 0; }
        }

        public bool IsFull
        {
            get { return count == capienza; }
        }
    }
}
