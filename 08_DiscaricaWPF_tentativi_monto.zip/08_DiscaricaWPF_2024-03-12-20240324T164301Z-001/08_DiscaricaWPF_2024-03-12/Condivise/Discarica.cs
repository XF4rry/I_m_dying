﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Impianto
{
    internal class Discarica
    {
        private int CapienzaIndifferenziata = 0;
        private int CapienzaCarta = 0;
        private int CapienzaPlastica = 0;
        private int CapienzaVetro = 0;
        int c = 0;
        private List<Camion> Coda = new List<Camion>(); 
        private List<Thread> Threads = new List<Thread>();
        public void ArrivoCamion()
        {

        generazione:
            bool si = true;

            while (si)
            {
                //Console.WriteLine("generazione camion "+(Coda.Count+1));
                if (Coda.Count < 4)//coda massima camion in ingresso è di 5
                {
                    Camion camion = new Camion();
                    Thread cam = new Thread(new ThreadStart(camion.RiempiCamion));
                    c++;
                    cam.Start();
                    Coda.Add(camion);
                    Threads.Add(cam);
                }
                else
                {
                    si = false;
                }
            }
            //Console.WriteLine("Inizio a smistare i camion");
            Smistamento();
            //Console.WriteLine("indifferenziata: "+CapienzaIndifferenziata);
            //Console.WriteLine("carta: "+CapienzaCarta);
            //Console.WriteLine("plastica: "+CapienzaPlastica);
            //Console.WriteLine("vetro: "+CapienzaVetro);
            Console.WriteLine("Camion numero: "+c);

            //Console.ReadKey();
            goto generazione;
        }

        public void Smistamento()
        {
            //Console.WriteLine("Inizio smistamento");
            //0 == vuoto, 1 == indifferenziata, 2 == carta, 3 == plastica, 4 == vetro
            int i = 0;
            //foreach (Camion c in Coda)
            while (i < Coda.Count)
            {
                switch (Coda[i].GetContenuto)
                {
                    case 0://il camion è vuoto e quindi muore
                        Coda[i].SetVita = false;
                        //Console.WriteLine("Il camion era vuoto");
                        Coda.Remove(Coda[i]);
                        //Threads[i].Abort();
                        
                        Threads.Remove(Threads[i]);
                        ControlloCapienza();
                        
                        break;
                    case 1:
                        Coda[i].SetVita = false;
                        //Console.WriteLine("Il camion era indifferenziata");
                        CapienzaIndifferenziata += Coda[i].Capienza;
                        
                        Coda.Remove(Coda[i]);//ora uccido il thread perchè è vuoto
                        Threads.Remove(Threads[i]);
                        ControlloCapienza();
                        

                        break;
                    case 2:
                        Coda[i].SetVita = false;
                        //Console.WriteLine("Il camion era carta");
                        CapienzaCarta += Coda[i].Capienza;
                        
                        Coda.Remove(Coda[i]);//ora uccido il thread perchè è vuoto
                        Threads.Remove(Threads[i]);
                        ControlloCapienza();
                        

                        break;
                    case 3:
                        Coda[i].SetVita = false;
                        //Console.WriteLine("Il camion era plastica");
                        CapienzaPlastica += Coda[i].Capienza;
                        
                        Coda.Remove(Coda[i]);//ora uccido il thread perchè è vuoto
                        Threads.Remove(Threads[i]);
                        ControlloCapienza();
                        

                        break;
                    case 4:
                        Coda[i].SetVita = false;
                        //Console.WriteLine("Il camion era vetro");
                        CapienzaVetro += Coda[i].Capienza;
                        
                        Coda.Remove(Coda[i]);//ora uccido il thread perchè è vuoto
                        Threads.Remove(Threads[i]);
                        ControlloCapienza();
                        

                        break;
                }

                i++;
            }
            //Console.WriteLine("fine smistamento");
            //foreach (Camion c in Coda)
            //{
            //    Console.WriteLine("|");
            //}
        }

        public void ControlloCapienza()
        {
            //la capienza massima possibile è 10_000 quindi il 70% di capienza piena è uando è a 7000
            if (CapienzaIndifferenziata >= 7000)
            {
                
                Console.WriteLine(":----------------------------------------:");
                Console.WriteLine("CAPIENZA DELL'INDIFFERENZIATA HA SUPERATO O RAGGIUNTO IL 70%");
                Console.WriteLine(":----------------------------------------:");
                Aspetta();
            }
            else if (CapienzaCarta >= 7000)
            {
                
                Console.WriteLine(":----------------------------------------:");
                Console.WriteLine("CAPIENZA DELLA CARTA HA SUPERATO O RAGGIUNTO IL 70%");
                Console.WriteLine(":----------------------------------------:");
                Aspetta();
            }
            else if (CapienzaPlastica >= 7000)
            {
                
                Console.WriteLine(":----------------------------------------:");
                Console.WriteLine("CAPIENZA DELLA PLASTICA HA SUPERATO O RAGGIUNTO IL 70%");
                Console.WriteLine(":----------------------------------------:");
                Aspetta();
            }
            else if (CapienzaVetro >= 7000)
            {
                
                Console.WriteLine(":----------------------------------------:");
                Console.WriteLine("CAPIENZA DEL VETRO HA SUPERATO O RAGGIUNTO IL 70%");
                Console.WriteLine(":----------------------------------------:");
                Aspetta();
            }
        }

        public void Aspetta()
        {
            Console.WriteLine("Ora sta aspettando");
            while (true)
            {

            }
        }
    }
}
