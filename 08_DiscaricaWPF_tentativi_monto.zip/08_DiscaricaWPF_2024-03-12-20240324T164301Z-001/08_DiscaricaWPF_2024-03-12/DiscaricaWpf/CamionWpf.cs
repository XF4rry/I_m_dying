﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace DiscaricaWpf
{
    public class CamionWpf
    {
        Random random = new Random();
        public enum TipoContenuto
        {
            IndifferenziataDaDiscarica,
            IndifferenziataDaSelezionare,
            //Carta,
            //Plastica,
            //Vetro
        }
        public static int NumCamionArrivati { get; private set; } = 0; 
        public Label Grafica { get; set; }
        public string Nome { get; set; }

        private double x = 0;
        private double y = 0;
        public double X {
            get { return x; } 
            
            set
            {
               x = value;
                Canvas.SetLeft(Grafica, X);
            }
        }
        public double Y 
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
                Canvas.SetTop(Grafica, Y);
            }
                
        }
    public bool SimulazioneOn { get; set; }  = true;
        public TipoContenuto Tipo { get; private set; }
        DateTime TempoInCoda { get; set; }  // ancora da usare

        public CamionWpf() {
            // conteggio del camion arrivati
            
            NumCamionArrivati++;

            // il camion ha come nome il numero del camion in arrivo 
            Nome = NumCamionArrivati.ToString("00000"); 
            Grafica = new Label();
            Grafica.Background = Brushes.SaddleBrown;
            Grafica.Foreground = Brushes.Yellow;
            Grafica.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Center;
            

            Grafica.Width = 60;
            Grafica.Height = 30;

            Grafica.Content = Nome;

            // il camion si dispone nella coda dei camion in arrivo, dietro al camion precedente
            X += (NumCamionArrivati - 1) * (Grafica.Width + 5);
            Y = 5;
            // !!!! il metodo precedente è alquanto brutto.
            // !!!! io modificherei la classe Buffer, aggiungendo per ogni elemento della coda 
            // !!!! le coordinate X e Y del posto dove deve stare l'oggetto "Grafica" del camion
            // che sta in quel posto della coda
            //Canvas.SetLeft(Grafica, X);
            //Canvas.SetTop(Grafica, Y);

            // sistemo il contenuto casualmente
            double r = random.NextDouble();//safe
            if (r < 0.3)//safe
            {
                Tipo = TipoContenuto.IndifferenziataDaSelezionare;
                Grafica.Background = Brushes.Khaki;
                Grafica.Foreground = Brushes.Black;
            }
            else//safe
            {
                Tipo = TipoContenuto.IndifferenziataDaDiscarica;
                Grafica.Background = Brushes.GreenYellow;
                Grafica.Foreground = Brushes.Black;
            }
            //Thread thread = new Thread(VitaDaCamion);
            //thread.Start();
        }
        // con la visualizzazione WPF non si può usare un altro thread.. 
        private void VitaDaCamion(object? obj)
        {
            // andare nel deposito di destino 
            while (SimulazioneOn) 
            {
                // le prossime non funzionano, cambio di approccio, niente Thread..
                //Canvas.SetTop(Grafica, Y);
                //Canvas.SetLeft(Grafica, X);
            }
        }
        internal void Visualizza()//safe
        {
            Canvas.SetLeft(Grafica, X);
            Canvas.SetTop(Grafica, Y);
        }
    }
}
