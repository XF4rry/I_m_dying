﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace DiscaricaWpf
{
    public class CamionWpf
    {
        Random random = new Random();
        public enum TipoContenuto
        {
            IndifferenziataDaDiscarica,
            IndifferenziataDaSelezionare,
            //Carta,
            //Plastica,
            //Vetro
        }
        public double[,] check = new double[30,3]; //1 pos. --> X, 2 pos. --> Y, 3 pos. --> libero = 0/occupato = 1
        public int i = 0;
        public static int NumCamionArrivati { get; private set; } = 0; 
        public Label Grafica { get; set; }
        public string Nome { get; set; }
        public double X { get; set; } = 0;
        public double Y { get; set; } = 0;
        public bool SimulazioneOn { get; set; }  = true;
        public TipoContenuto Tipo { get; private set; }
        DateTime TempoInCoda { get; set; }  // ancora da usare

        public CamionWpf() {
            // conteggio del camion arrivati
            NumCamionArrivati++;

            // il camion ha come nome il numero del camion in arrivo 
            Nome = NumCamionArrivati.ToString("00000"); 
            Grafica = new Label();
            Grafica.Background = Brushes.SaddleBrown;
            Grafica.Foreground = Brushes.Yellow;
            Grafica.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Center;

            Grafica.Width = 60;
            Grafica.Height = 30;

            X = 0;
            Y = 5;

            Grafica.Content = Nome;
            check[i,0] = X;
            check[i,1] = Y;
            check[i,2] = 0;
            // il camion si dispone nella coda dei camion in arrivo, dietro al camion precedente
            for (int j = 0;j < 30; j++) 
            {
                if (check[j, 2] == 0)
                {
                    X = check[j, 0];
                    Y = check[j, 1];
                } else if (check[j, 2] == 0 && check[j, 0] == 0) 
                {
                    X += (NumCamionArrivati - 1) * (Grafica.Width + 5);
                    Y = 5;
                }
            }
            
            // !!!! il metodo precedente è alquanto brutto.
            // !!!! io modificherei la classe Buffer, aggiungendo per ogni elemento della coda 
            // !!!! le coordinate X e Y del posto dove deve stare l'oggetto "Grafica" del camion
            // che sta in quel posto della coda
            Canvas.SetLeft(Grafica, X);
            Canvas.SetTop(Grafica, Y);

            // sistemo il contenuto casualmente
            double r = random.NextDouble();
            if (r < 0.3)
            {
                Tipo = TipoContenuto.IndifferenziataDaSelezionare;
                Grafica.Background = Brushes.Khaki;
                Grafica.Foreground = Brushes.Black;
            }
            else
            {
                Tipo = TipoContenuto.IndifferenziataDaDiscarica;
                Grafica.Background = Brushes.GreenYellow;
                Grafica.Foreground = Brushes.Black;
            }
            //Thread thread = new Thread(VitaDaCamion);
            //thread.Start();
        }
        // con la visualizzazione WPF non si può usare un altro thread.. 
        private void VitaDaCamion(object? obj)
        {
            // andare nel deposito di destino 
            while (SimulazioneOn) 
            {
                // le prossime non funzionano, cambio di approccio, niente Thread..
                //Canvas.SetTop(Grafica, Y);
                //Canvas.SetLeft(Grafica, X);
            }
        }
        internal void Visualizza()
        {
            Canvas.SetLeft(Grafica, X);
            Canvas.SetTop(Grafica, Y);
        }
    }
}
