﻿using Impianto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace DiscaricaWpf
{
    internal class DepositoWpf
    {
        private double bordo = 3;

        internal Label Grafica { get; set; }
        internal string Nome { get; set; }
        internal double X { get; private set; } = 150;
        internal double Y { get; private set; } = 20;
        internal Buffer<CamionWpf> CamionInAttesa { get; private set; }

        public DepositoWpf(string nome, double X, double Y, int NMaxCamionInCoda)
        {
            CamionInAttesa = new Buffer<CamionWpf>(NMaxCamionInCoda); 
            // il camion ha come Nome e come etichetta il numero del camion in arrivo 
            Nome = nome;
            Grafica = new Label();
            Grafica.Background = Brushes.Transparent;
            Grafica.Foreground = Brushes.Black;
            Grafica.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Center;
            Grafica.BorderThickness = new System.Windows.Thickness(3);
            Grafica.BorderBrush = Brushes.Black;
            // posiziono il deposito nel Canvas alle coordinate passate come parametro 
            Canvas.SetLeft(Grafica, X);
            Canvas.SetTop(Grafica, Y);
            // cambio le dimensioni del deposito
            Grafica.Width = 300;
            Grafica.Height = 100;
            Grafica.Content = Nome;
        }
        internal void AggiungiCamionInCoda(CamionWpf camion)
        {
            CamionInAttesa.Aggiungi(camion);
            double fondoY = Canvas.GetTop(Grafica) + Grafica.Height;
            double fondoX = Canvas.GetLeft(Grafica) + Grafica.Width;
            // queste coordinate sono da migliorare
            camion.Y = fondoY - bordo - camion.Grafica.Height;
            camion.X = fondoX - bordo - CamionInAttesa.Count * camion.Grafica.Width;

            // memorizza nel camion il tempo di ingresso nella coda di nquesto deposito
        }

        internal void TogliCamionDallaCoda(CamionWpf camion)
        {
            // ???? qua lavorate voi

            // memorizza nel camion il tempo di permanenza nella coda
        }
    }
}
