﻿using Impianto;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace DiscaricaWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Random random = new Random();

        // il tempo verrà compresso di fattoreDiCompressioneTempo volte, dividendo gli intervalli 
        // per fattoreDiCompressioneTempo
        double fattoreDiCompressioneTempo = 50;
        int tempoMassimoFraCamion = 600_000; // 10 minuti in millisecondi (ms)

        DispatcherTimer timerAnimazione = new();
        DispatcherTimer timerNuovoCamion = new();
        
        List<CamionWpf> listaCamion= new List<CamionWpf>();

        DepositoWpf discarica, selezioneIn;
        // coda di camion che attendono di entrare nell'impianto (max 30 camion)
        Buffer<CamionWpf> codaInIngresso = new Buffer<CamionWpf>(30);
        
        public MainWindow()
        {
            InitializeComponent();

            discarica = new DepositoWpf("Discarica", 0, 40, 10);
            selezioneIn = new DepositoWpf("SelezioneIn", 350, 40, 6);

            GraficaSimulazione.Children.Add(discarica.Grafica);
            GraficaSimulazione.Children.Add(selezioneIn.Grafica);

            //CamionWpf c; 
            //// genero i primi N camion
            //for (int i = 0 ; i < 5; i++)
            //{
            //    c = new CamionWpf();
            //    listaCamion.Add(c);
            //    GraficaSimulazione.Children.Add(c.Grafica);
            //}

            //Canvas.SetZIndex(discarica.Grafica, 0);
            //Canvas.SetZIndex(selezioneIn.Grafica, 0);

            // definizione del timer, per farlo scattare ogni 100 ms 
            timerAnimazione.Interval = TimeSpan.FromMilliseconds(100);
            timerAnimazione.Tick += AggiornamentoUI; // solo il nome del metodo, niente parentesi! 
            //timerAnimazione.Start(); // spostato sotto il bottone di start 

            // definizione di un timer che farà arrivare un nuovo camion, con un intervallo di tempo casuale
            // il primo camion arriva subto, dopo 2 ms
            timerNuovoCamion.Interval = TimeSpan.FromMilliseconds(2);
            timerNuovoCamion.Tick += ArrivoNuovoCamion; // solo il nome del metodo, niente parentesi! 
            //timerNuovoCamion.Start(); // spostato sotto il bottone di start 
        }
        private void AggiornamentoUI(object? sender, EventArgs e)
        {
            foreach (CamionWpf camion in listaCamion)
            {
                camion.Visualizza();
            }
        }
        private void ArrivoNuovoCamion(object? sender, EventArgs e)
        {
            timerNuovoCamion.Stop();
            // creazione di un nuovo camion
            CamionWpf c = new CamionWpf();
            // aggiunta del nuovo camion alla lista di tutti i camion che sono nell'impianto
            listaCamion.Add(c);
            // aggiunta del camion al buffer circolare di camion che sono in attesa di entrare nell'impianto
            codaInIngresso.Aggiungi(c);
            // aggiunta del rettangolo del camion al  Canvas
            GraficaSimulazione.Children.Add(c.Grafica);
            // riprogrammo il timer per generare il prossimo camion, con un tempo casuale fra
            // 1 decimo del tempoMassimoFraCamion ed il tempoMassimoFraCamion 
            int msTempoReale = random.Next(tempoMassimoFraCamion/10, tempoMassimoFraCamion);
            int msTempoCompresso = (int)(msTempoReale / fattoreDiCompressioneTempo); 
            timerNuovoCamion.Interval = TimeSpan.FromMilliseconds(msTempoCompresso);
            timerNuovoCamion.Start();
        }
        private void AssegnaCamionADeposito(CamionWpf c)
        {
            if (c.Tipo == CamionWpf.TipoContenuto.IndifferenziataDaSelezionare)
                selezioneIn.AggiungiCamionInCoda(c);
            else if (c.Tipo == CamionWpf.TipoContenuto.IndifferenziataDaDiscarica)
                discarica.AggiungiCamionInCoda(c); 
        }
        private void btnStart_Click(object sender, RoutedEventArgs e)
        {           
            timerAnimazione.Start();
            timerNuovoCamion.Start();
        }
        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            // prendo il primo camion della coda fuori dall'impianto
            CamionWpf c = codaInIngresso.Togli(); 
            // in base al tipo di carico del camion, lo assegno al deposito
            AssegnaCamionADeposito(c);

            // !!!! TODO !!!! i camion in coda devono scorrere sostituendo quello che è appena entrato
        }
        private void btnStop_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}